// aws-exports.ts
// AWS Amplify configuration for PRAHARI
// Replace placeholder values with your actual AWS credentials

const awsConfig = {
  aws_project_region: 'ap-south-1',

  // Cognito Identity Pool
  aws_cognito_identity_pool_id: 'ap-south-1:xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx',
  aws_cognito_region: 'ap-south-1',

  // Cognito User Pool
  aws_user_pools_id: 'ap-south-1_XXXXXXXXX',
  aws_user_pools_web_client_id: 'xxxxxxxxxxxxxxxxxxxxxxxxxx',

  // S3 Storage
  aws_user_files_s3_bucket: 'datalake-attendance-sync',
  aws_user_files_s3_bucket_region: 'ap-south-1',

  Storage: {
    AWSS3: {
      bucket: 'datalake-attendance-sync',
      region: 'ap-south-1',
      level: 'private', // Each device's data is isolated
    },
  },
};

export default awsConfig;
